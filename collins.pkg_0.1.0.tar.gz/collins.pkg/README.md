# collins.pkg

## An R package for crabs data 

cleans, analyzes, and mutate data set
